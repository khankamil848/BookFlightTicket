package com.clearTrip.actions;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.clearTrip.pageobjects.FlightSearchResultsPage;
import com.clearTrip.utils.CommonMethods;
import com.clearTrip.utils.SeleniumDriver;
import com.cucumber.listener.Reporter;

public class FlightSearchResultsActions {

	FlightSearchResultsPage flightSearchResultsPageLoc = null;

	public FlightSearchResultsActions() {
		flightSearchResultsPageLoc = new FlightSearchResultsPage();
		PageFactory.initElements(SeleniumDriver.getDriver(), flightSearchResultsPageLoc);
	}

	public List<WebElement> getDepartureFlightsList() {
		return flightSearchResultsPageLoc.SearchResults_FromFlightsListView;
	}

	public List<WebElement> getReturnFlightsList() {
		return flightSearchResultsPageLoc.SearchResults_ReturnFlightsListView;
	}

	public void clickBookTikcetsButton() {
		new CommonMethods().presenceOfTheElement(flightSearchResultsPageLoc.SearchResults_BookTicket).click();

	}

	public void clickToChooseDeparture_ReturnFlights(List<WebElement> departList, List<WebElement> returnList,
			int depart, int retu) {
		Reporter.addStepLog("Selecting " + depart + "Flight");
		WebElement departelement = departList.get(depart);
		departelement.click();
		Reporter.addStepLog("Selecting " + retu + "Flight");
		WebElement Returnelement = returnList.get(retu);
		Returnelement.click();

	}

	public void getRowDetails(WebElement listview, int row) throws Throwable {
		if (flightSearchResultsPageLoc.SearchResults_FromFlightsListView.size() > 0)
			System.out.println("found");
		else
			System.out.println("not found");
			WebElement element = listview.findElement(By.xpath("li[" + row + "]"));
		}

	public java.util.List<String> getSelectedRowData(List<WebElement> listview, int row) throws Throwable {

		WebElement element = listview.get(row);
		java.util.List<String> flightData = new ArrayList<String>();
		List<WebElement> colData = element.findElements(By.tagName("p"));
		System.out.println("table column size:" + colData.size());
		for (int i = 0; i < colData.size(); i++) {
			String str = colData.get(i).getText();
			Reporter.addStepLog(colData.get(i).getAttribute("class") + ":" + str);
			System.out.println(colData.get(i).getAttribute("class") + ":" + str);
			flightData.add(str);
		}

		return flightData;

	}

}
