package com.clearTrip.pageobjects;

import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class FlightSearchResultsPage {
	
	@FindBy(xpath="//div[@data-test-attrib='onward-view']//div[@class='rt-tuple-container__details ms-grid-row-2']")
	public List<WebElement> SearchResults_FromFlightsListView;
	
	@FindBy(xpath="//div[@data-test-attrib='return-view']//div[@class='rt-tuple-container__details ms-grid-row-2']")
	public List<WebElement> SearchResults_ReturnFlightsListView;
	
	@FindBy(how=How.XPATH,using="//button[text()='Book']")
	public WebElement SearchResults_BookTicket;
	
	
	

}
