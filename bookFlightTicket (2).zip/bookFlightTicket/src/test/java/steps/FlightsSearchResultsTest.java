package steps;

import java.util.ArrayList;
import java.util.List;

import com.clearTrip.actions.FlightSearchResultsActions;
import com.clearTrip.actions.ItineraryActions;
import com.clearTrip.utils.CommonMethods;
import com.clearTrip.utils.GetScreenShot;
import com.clearTrip.utils.SeleniumDriver;
import com.cucumber.listener.Reporter;

import cucumber.api.java.en.Then;

public class FlightsSearchResultsTest {
	
	public static List<String> onWardFlightDetails=new ArrayList<String>();
	public static List<String> returnFlightDetails=new ArrayList<String>();
	
	FlightSearchResultsActions searchActions=new FlightSearchResultsActions();
	
	@Then("^I wait For Results to Apper on the Screen$")
	public void i_wait_For_Results_to_Apper_on_the_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}
	
	@Then("^I select (\\d+) Flight and (\\d+) flight to book tickets$")
	public void i_select_Flight_and_flight_to_book_tickets(int depart, int retr) throws Throwable {
	    
		new GetScreenShot();
		String beforeSelect=GetScreenShot.capture(SeleniumDriver.getDriver(), "beforeSelect");
		Reporter.addScreenCaptureFromPath(beforeSelect, "Before selection of Flights");
	    searchActions.clickToChooseDeparture_ReturnFlights(searchActions.getDepartureFlightsList(), searchActions.getReturnFlightsList(), depart, retr);
		Reporter.addStepLog("After Selecting From and To Flights");
		new GetScreenShot();
		String AfterSelect=GetScreenShot.capture(SeleniumDriver.getDriver(), "AfterSelect");
		Reporter.addScreenCaptureFromPath(AfterSelect, "After selection of Flights");
	}

	@Then("^I read departure Flights (\\d+) rowData$")
	public void i_read_DepartureFlights_rowData(int row) throws Throwable {
	   
		
		onWardFlightDetails=searchActions.getSelectedRowData(searchActions.getDepartureFlightsList(),row);
		System.out.println("onWardFlightDetails and row "+row+ ":"+onWardFlightDetails);
	}
	
	@Then("^I read Return Flights (\\d+) rowData$")
	public void i_read_ReturnFlights_rowData(int row) throws Throwable {
	   
		returnFlightDetails=searchActions.getSelectedRowData(searchActions.getReturnFlightsList(),row);
		System.out.println("returnFlightDetails and row "+row+ ":"+returnFlightDetails);
	}
	@Then("^I Book the Tickets$")
	public void i_Book_Tickets() throws Throwable {
	   
		searchActions.clickBookTikcetsButton();
		new CommonMethods().waitFor(20000);
		new GetScreenShot();
		String reivewPage=GetScreenShot.capture(SeleniumDriver.getDriver(), "reivewPage");
		Reporter.addScreenCaptureFromPath(reivewPage, "Checkout Page");
	}
	
	@Then("^I read ItenaryDetails$")
	public void i_Read_ItineraryDetails() throws Throwable {
	   
		new ItineraryActions().getOnwardJourneyFlightDetails();
		new ItineraryActions().getReturnJourneyFlightDetails();
		new ItineraryActions().verifyItineraryOnWardFlightDetails_With_SearchPageOnwardFlightDetails();
		new ItineraryActions().verifyItineraryReturnFlightDetails_With_SearchPageRetunFlightDetails();
		
	}
	 

}
